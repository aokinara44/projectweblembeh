
<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PageController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\ServiceCategoryController;
use App\Http\Controllers\Admin\ServiceController;
use App\Http\Controllers\Admin\GalleryCategoryController;
use App\Http\Controllers\Admin\GalleryController;
use App\Http\Controllers\Admin\ReviewController;
use App\Http\Controllers\Admin\UserController;
use App\Http\Controllers\SitemapController;
use App\Http\Middleware\SetLocale;

// Sitemap
Route::get('/sitemap.xml', [SitemapController::class, 'generate'])->name('sitemap');

// == RUTE PUBLIK (FRONTEND) ==
// Semua route publik harus punya prefix locale
Route::prefix('{locale}')
    ->where(['locale' => '[a-zA-Z]{2}'])
    ->middleware(SetLocale::class) // Middleware dijalankan SETELAH prefix valid
    ->group(function () {
        Route::get('/', [PageController::class, 'home'])->name('home'); // Name: home
        Route::get('/services', [PageController::class, 'services'])->name('services'); // Name: services
        Route::get('/gallery', [PageController::class, 'gallery'])->name('gallery');   // Name: gallery
        Route::get('/reviews', [PageController::class, 'reviews'])->name('reviews');   // Name: reviews
        Route::get('/divespots', [PageController::class, 'diveSpots'])->name('divespots'); // Name: divespots
        Route::get('/contact', [PageController::class, 'contact'])->name('contact');     // Name: contact
        Route::post('/contact', [PageController::class, 'submitContact'])->name('contact.submit'); // Name: contact.submit
    });

// Redirect jika akses root (/) tanpa locale
Route::get('/', function () {
    // Ambil locale dari session atau fallback, lalu redirect
    $locale = session('locale', config('app.fallback_locale', 'en'));
    // Redirect ke route 'home' yang sudah BENAR (punya prefix)
    return redirect()->route('home', ['locale' => $locale]);
});

// == RUTE ADMIN (BACKEND) ==
Route::middleware(['auth', 'verified'])->prefix('admin')->group(function () {
    Route::name('admin.')->group(function () {
        Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard'); // Name: admin.dashboard
        Route::resource('service-categories', ServiceCategoryController::class);
        Route::resource('services', ServiceController::class);
        Route::resource('gallery-categories', GalleryCategoryController::class);
        Route::resource('galleries', GalleryController::class);
        Route::resource('reviews', ReviewController::class);
        Route::resource('users', UserController::class);
        Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');   // Name: admin.profile.edit
        Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update'); // Name: admin.profile.update
        Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');// Name: admin.profile.destroy
    });
});

// Auth routes (bawaan Breeze)
require __DIR__ . '/auth.php';

// HAPUS FALLBACK Route::get('/{locale}') karena sudah dihandle middleware dan redirect root