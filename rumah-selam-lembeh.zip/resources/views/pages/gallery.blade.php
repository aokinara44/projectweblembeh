<x-main-layout>
    @push('head')
        {{-- Lightbox CSS --}}
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/glightbox/3.2.0/css/glightbox.min.css" integrity="sha512-T+KoG3fbDoSnlgEXFQqwcTC9AdkFIxhBlmoaFqYaIjq2ShhNwNao9AKaLUPMfwiBPLigppBR TavQAtXk9zw9rw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
        <style>
            .category-button { transition: all 0.3s ease; }
            .category-button.active { background-color: #FACC15; color: #1E3A8A; } /* yellow-400, blue-800 */
            .category-button:not(.active):hover { background-color: #DBEAFE; } /* blue-100 */
        </style>
    @endpush

    {{-- Header Page --}}
    <section class="bg-gradient-to-r from-blue-800 to-indigo-900 text-white pt-32 pb-16 shadow-xl">
        <div class="container mx-auto px-6 text-center">
            <h1 class="text-4xl md:text-5xl font-bold mb-4">{{ __('Gallery') }}</h1>
            <p class="text-lg md:text-xl text-blue-200">{{ __('Explore the stunning underwater world of Lembeh Strait.') }}</p>
        </div>
    </section>

    {{-- Gallery Content --}}
    <section class="py-16 bg-gray-50" x-data="{ selectedCategory: 'all' }">
        <div class="container mx-auto px-6">
            {{-- Category Filters --}}
            <div class="flex flex-wrap justify-center gap-2 md:gap-4 mb-12">
                <button @click="selectedCategory = 'all'"
                        :class="selectedCategory === 'all' ? 'active' : ''"
                        class="category-button px-4 py-2 rounded-full border border-gray-300 text-gray-700 bg-white font-medium text-sm md:text-base">
                    {{ __('All') }}
                </button>
                {{-- !! PERBAIKAN: Gunakan $galleryCategories !! --}}
                @foreach($galleryCategories as $category)
                    <button @click="selectedCategory = '{{ $category->slug }}'"
                            :class="selectedCategory === '{{ $category->slug }}' ? 'active' : ''"
                            class="category-button px-4 py-2 rounded-full border border-gray-300 text-gray-700 bg-white font-medium text-sm md:text-base">
                        {{ $category->getTranslation('name', app()->getLocale()) }} {{-- Tampilkan nama kategori --}}
                    </button>
                @endforeach
            </div>

            {{-- Image Grid --}}
            <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4 md:gap-6">
                 {{-- !! PERBAIKAN: Gunakan $galleryCategories !! --}}
                @forelse($galleryCategories as $category)
                    @foreach ($category->galleries as $gallery)
                        <a href="{{ Storage::url($gallery->image_path) }}"
                           class="glightbox block rounded-lg overflow-hidden shadow-md group relative aspect-square transition-opacity duration-300"
                           data-gallery="gallery-{{ $category->slug }}"
                           :data-category-slug="'{{ $category->slug }}'"
                           x-show="selectedCategory === 'all' || selectedCategory === '{{ $category->slug }}'"
                           x-transition:enter="transition ease-out duration-300"
                           x-transition:enter-start="opacity-0 scale-95"
                           x-transition:enter-end="opacity-100 scale-100"
                           x-transition:leave="transition ease-in duration-200"
                           x-transition:leave-start="opacity-100 scale-100"
                           x-transition:leave-end="opacity-0 scale-95"
                           x-cloak>
                            <img src="{{ Storage::url($gallery->image_path) }}"
                                 alt="{{ $gallery->getTranslation('title', app()->getLocale(), false) }}"
                                 title="{{ $gallery->getTranslation('title', app()->getLocale(), false) }}" {{-- Tooltip --}}
                                 class="w-full h-full object-cover transform group-hover:scale-110 transition duration-300"
                                 loading="lazy">
                            {{-- Overlay with Title (optional) --}}
                            <div class="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-40 transition duration-300 flex items-end justify-center p-2">
                                <p class="text-white text-xs text-center opacity-0 group-hover:opacity-100 transition duration-300 truncate">
                                    {{ $gallery->getTranslation('title', app()->getLocale(), false) }}
                                </p>
                            </div>
                        </a>
                    @endforeach
                @empty
                    <p class="col-span-full text-center text-gray-500">{{ __('No images found in the gallery yet.') }}</p>
                @endforelse
            </div>
        </div>
    </section>

    @push('scripts')
        {{-- Lightbox JS --}}
        <script src="https://cdnjs.cloudflare.com/ajax/libs/glightbox/3.2.0/js/glightbox.min.js" integrity="sha512-S/H9RQ6govCzeA7F9D0m8NGfsGf0/HjJEiLEfWGaMCjFzavo+DkRbYtZLSO+X6cZsIKQ6JvV/7Y9YMaYnSGnAA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
        <script>
            // Inisialisasi GLightbox
            document.addEventListener('DOMContentLoaded', () => {
                const lightbox = GLightbox({
                    selector: '.glightbox', // Gunakan class yang kita pasang di link
                    touchNavigation: true,
                    loop: true,
                    // Optional: deskripsi dari title atau alt
                    descPosition: 'bottom',
                    // Gunakan slug kategori untuk grouping (jika ingin galeri per kategori)
                    // Kita pakai data-gallery attribute yang sudah dibuat
                });

                 // Re-initialize lightbox when Alpine.js changes visibility
                 // This might be needed if elements are initially hidden
                 // But since we use x-show, direct initialization might be enough
                 // However, if filtering causes issues, uncomment the next lines
                 // Alpine.effect(() => {
                 //    lightbox.reload();
                 // });
            });
        </script>
    @endpush

</x-main-layout>