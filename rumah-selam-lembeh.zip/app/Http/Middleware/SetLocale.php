<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Session;
use Symfony\Component\HttpFoundation\Response;

class SetLocale
{
    /**
     * Handle an incoming request.
     * Atur locale aplikasi berdasarkan segmen URL, session, atau fallback.
     * Redirect jika perlu (misal: akses root tanpa locale, atau URL tanpa locale padahal session punya).
     */
    public function handle(Request $request, Closure $next): Response
    {
        $availableLocales = Config::get('app.available_locales', []);
        $fallbackLocale = Config::get('app.fallback_locale', 'en');

        // Ambil locale dari segmen URL pertama
        $urlLocale = $request->segment(1);

        // Periksa apakah path adalah root '/'
        $isRootPath = $request->path() === '/';

        // Cek apakah segmen pertama adalah locale yang valid
        $isValidUrlLocale = $urlLocale && array_key_exists($urlLocale, $availableLocales);

        $targetLocale = null;
        $shouldRedirect = false;
        $redirectTo = '';

        // Kasus 1: URL punya locale valid (contoh: /en/services)
        if ($isValidUrlLocale) {
            $targetLocale = $urlLocale;
            Session::put('locale', $targetLocale); // Simpan ke session
        }
        // Kasus 2: URL TIDAK punya locale valid (contoh: /, /services, /admin)
        else {
            // Coba ambil dari session
            if (Session::has('locale') && array_key_exists(Session::get('locale'), $availableLocales)) {
                $targetLocale = Session::get('locale');
            }
            // Jika tidak ada di session, gunakan fallback
            else {
                $targetLocale = $fallbackLocale;
                Session::put('locale', $targetLocale); // Simpan fallback ke session
            }

            // PERIKSA APAKAH PERLU REDIRECT
            // Hanya redirect jika request BUKAN ke admin, storage, file build, dll.
            // dan jika path BUKAN root (karena root punya redirect sendiri di web.php)
            $currentPath = $request->path();
            if (!$isRootPath && !preg_match('/^(admin|storage|_ignition|build|images|favicon\.ico|sitemap\.xml)/', $currentPath)) {
                $shouldRedirect = true;
                $redirectTo = url($targetLocale . '/' . ltrim($currentPath, '/')); // Bangun URL baru
            }
        }

        // Jika perlu redirect, lakukan sekarang
        if ($shouldRedirect) {
            return redirect()->to($redirectTo);
        }

        // Set locale aplikasi JIKA targetLocale sudah ditentukan
        if ($targetLocale) {
            App::setLocale($targetLocale);
        } else {
            // Fallback jika tidak ada logic di atas yang cocok (seharusnya tidak terjadi)
             App::setLocale($fallbackLocale);
        }

        // Lanjutkan request ke controller atau middleware berikutnya
        return $next($request);
    }
}