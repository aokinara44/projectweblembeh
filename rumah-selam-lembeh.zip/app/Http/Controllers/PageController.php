<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Service;
use App\Models\ServiceCategory;
use App\Models\Gallery;
use App\Models\GalleryCategory;
use App\Models\Review;
// Hapus use Post dan PostCategory karena sudah tidak dipakai
// use App\Models\Post;
// use App\Models\PostCategory;
use Illuminate\Support\Facades\File; // Tambahkan ini untuk membaca file

class PageController extends Controller
{
    /**
     * Menampilkan halaman Home.
     */
    public function home()
    {
        // Ambil 3 service unggulan (contoh, bisa disesuaikan logikanya)
        // Kita beri alias 'featuredServices' sesuai view baru
        $featuredServices = Service::with('serviceCategory')->latest()->take(5)->get(); // Ambil 5 untuk slider

        // Ambil 3 review terbaru (contoh)
        // Kita beri alias 'latestReviews' sesuai view baru
        $latestReviews = Review::latest()->take(5)->get(); // Ambil 5 untuk slider

        // !! PERSIAPAN DATA HERO SLIDER !!
        // Misal, gambar hero ada di public/images/hero/
        $heroImages = [];
        $heroPath = public_path('images/hero'); // Pastikan folder ini ada
        if (File::isDirectory($heroPath)) {
            $files = File::files($heroPath);
            foreach ($files as $file) {
                // Hanya ambil path relatif dari folder public
                $heroImages[] = 'images/hero/' . $file->getFilename();
            }
        }
        // Jika tidak ada gambar, bisa siapkan default
        // if (empty($heroImages)) {
        //     $heroImages = ['images/default-hero.jpg']; // Contoh
        // }

        // Kirim data ke view 'welcome'
        return view('welcome', compact('featuredServices', 'latestReviews', 'heroImages'));
    }

    /**
     * Menampilkan halaman Services.
     */
    public function services()
    {
        $serviceCategories = ServiceCategory::with('services')->get();
        return view('pages.services', compact('serviceCategories'));
    }

    /**
     * Menampilkan halaman Gallery.
     */
    public function gallery()
    {
        $galleryCategories = GalleryCategory::with('galleries')->get();
        return view('pages.gallery', compact('galleryCategories'));
    }

    /**
     * Menampilkan halaman Dive Spots. (Nama method disesuaikan dengan route)
     */
    public function diveSpots() // <-- Ubah nama method
    {
        return view('pages.divespots');
    }

    /**
     * Menampilkan halaman Reviews.
     */
    public function reviews()
    {
        $reviews = Review::latest()->paginate(10); // Ambil semua dengan paginasi
        return view('pages.reviews', compact('reviews'));
    }

    /**
     * Menampilkan halaman Contact.
     */
    public function contact()
    {
        return view('pages.contact');
    }

     /**
     * Menangani submit form Contact. (Method ditambahkan sesuai route)
     */
    public function submitContact(Request $request) // <-- Tambah method
    {
        // TODO: Tambahkan validasi dan logika pengiriman email kontak
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|max:255',
            'message' => 'required|string|min:10',
        ]);

        // Logika kirim email... (Contoh)
        // Mail::to('admin@rumahselam.com')->send(new ContactFormMail($validated));

        return back()->with('success', __('contact.form.success')); // Kirim pesan sukses
    }
}